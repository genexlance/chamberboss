# Chamber Boss Plugin - Debugging Tasks

## 🐛 Current Issues to Debug

### Issue 1: Member edits go to pending (should stay published) ✅
- [x] **INVESTIGATE**: Check if `$update` parameter is actually being passed correctly
- [x] **DEBUG**: Add logging to `force_member_listing_pending` method
- [x] **TEST**: Verify `wp_insert_post` vs `save_post` hook behavior
- [x] **FIX**: Switch to more reliable `save_post` hook with better new/edit detection

### Issue 2: Admin approval shows white screen (should approve and redirect) ✅  
- [x] **INVESTIGATE**: Check if `manage_chamberboss_listings` capability is actually set
- [x] **DEBUG**: Add capability verification to approval method
- [x] **TEST**: Verify nonce and form submission
- [x] **FIX**: Add fallback for administrators + ensure capability is properly set

## 🔧 Debugging Strategy

### Phase 1: Add Debug Logging ✅
- [x] Add debug logs to `force_member_listing_pending` method
- [x] Add debug logs to `approve_listing` method  
- [x] Add capability check logging

### Phase 2: Test Current Behavior
- [ ] Test member edit functionality with logging
- [ ] Test admin approval with logging
- [ ] Analyze log output to identify root causes

### Phase 3: Implement Fixes ✅
- [x] Fix hook/parameter issues for member edits (switched to `save_post` hook)
- [x] Fix capability issues for admin approval (added admin fallback + timing fix)
- [ ] Test fixes thoroughly

### Phase 4: Cleanup
- [ ] Remove debug logging
- [ ] Update plugin version
- [ ] Document fixes

## 📋 Current Status
- **Plugin Version**: 1.0.31
- **Issues**: Both member edit and admin approval not working despite attempted fixes
- **Next Step**: Add comprehensive debugging to identify root causes